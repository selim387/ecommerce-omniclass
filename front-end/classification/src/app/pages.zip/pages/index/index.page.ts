import { Component, OnInit } from '@angular/core';
//import { main } from '../../../assets/templates/js/main';
//import * as $ from "jquery";

@Component({
  selector: 'app-index',
  templateUrl: './index.page.html',
  styleUrls: ['./index.page.scss'],
})
export class IndexPage implements OnInit {

  constructor() { }

  ngOnInit() {
  //  main($)
  }

}
