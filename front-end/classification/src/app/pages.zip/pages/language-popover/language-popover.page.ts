import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-popover',
  templateUrl: './language-popover.page.html',
  styleUrls: ['./language-popover.page.scss'],
})
export class LanguagePopoverPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
