import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error400',
  templateUrl: './error400.page.html',
  styleUrls: ['./error400.page.scss'],
})
export class Error400Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
