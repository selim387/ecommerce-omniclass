import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-directory',
  templateUrl: './contact-directory.page.html',
  styleUrls: ['./contact-directory.page.scss'],
})
export class ContactDirectoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
