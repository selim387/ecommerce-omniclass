import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-highchart',
  templateUrl: './highchart.page.html',
  styleUrls: ['./highchart.page.scss'],
})
export class HighchartPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
