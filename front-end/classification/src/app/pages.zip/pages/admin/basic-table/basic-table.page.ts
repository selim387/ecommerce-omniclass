import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-table',
  templateUrl: './basic-table.page.html',
  styleUrls: ['./basic-table.page.scss'],
})
export class BasicTablePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
