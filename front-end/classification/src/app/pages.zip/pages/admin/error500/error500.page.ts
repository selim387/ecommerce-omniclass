import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error500',
  templateUrl: './error500.page.html',
  styleUrls: ['./error500.page.scss'],
})
export class Error500Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
