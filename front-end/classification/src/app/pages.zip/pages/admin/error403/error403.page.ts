import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error403',
  templateUrl: './error403.page.html',
  styleUrls: ['./error403.page.scss'],
})
export class Error403Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
