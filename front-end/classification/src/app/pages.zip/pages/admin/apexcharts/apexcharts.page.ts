import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apexcharts',
  templateUrl: './apexcharts.page.html',
  styleUrls: ['./apexcharts.page.scss'],
})
export class ApexchartsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
