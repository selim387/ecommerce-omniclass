import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error503',
  templateUrl: './error503.page.html',
  styleUrls: ['./error503.page.scss'],
})
export class Error503Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
