import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-wizard',
  templateUrl: './form-wizard.page.html',
  styleUrls: ['./form-wizard.page.scss'],
})
export class FormWizardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
