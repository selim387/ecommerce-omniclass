import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.page.html',
  styleUrls: ['./datatable.page.scss'],
})
export class DatatablePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
